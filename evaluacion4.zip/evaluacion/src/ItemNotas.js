import React from "react";

function ItemNotas(props){
    return(
        <div className="container">{props.notas}</div>
    )
}
export default ItemNotas