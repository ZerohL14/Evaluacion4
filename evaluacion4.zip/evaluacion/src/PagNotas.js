import React, { useState, useEffect, useRef } from "react";
import ItemNotas from "./ItemNotas";
import './Estilo.css'
import { v4 as uuid } from "uuid";

function PagNotas() {
  const [notas, setNotas] = useState([]);
  const [titulo, setTitulo] = useState('');
  const [desc, setDesc] = useState('');
  const [importante, setImportante] = useState(false);
  const [error, setError] = useState(false);

  const tituloRef = useRef(null);
  const descRef = useRef(null);

  const KEY = 'notas-app-notas';

  // Función guardado local
  useEffect(() => {
    const misNotas = JSON.parse(localStorage.getItem(KEY));
    if (misNotas) {
      setNotas(misNotas);
    }
  }, []);

  useEffect(() => {
    const json = JSON.stringify(notas);
    localStorage.setItem(KEY, json);
  }, [notas]);

  // Funciones para los campos de texto
  const handleTituloChange = (e) => {
    setTitulo(e.target.value);
  };

  const handleDescChange = (e) => {
    setDesc(e.target.value);
  };

  // Función botón
  const agregarNota = (n) => {
    n.preventDefault();

    if (titulo === '' || desc === '') {
      setError(true);
      return;
    }

    setNotas([...notas, { id: uuid(), titulo, desc, importante }]);
    setTitulo('');
    setDesc('');
    setImportante(false);
    setError(false);

    tituloRef.current.value = '';
    descRef.current.value = '';
  };

  return (
      <div id="code" className="container mt-4">
        <h1>Listado tareas</h1>
        <form onSubmit={agregarNota} className="mb-4">
          <div id="cuadrado" className="input-group" style={{ backgroundColor: "#DF3A01", padding: "30px", borderRadius: "10px", boxShadow: "0 0 10px rgba(0, 0, 0, 0.2)" }}>
            <div className="col-md-3">
              <input ref={tituloRef} type="text" className="form-control me-2" placeholder="Titulo" value={titulo} onChange={handleTituloChange}/>
            </div>
            <div className="col-md-3">
            <input ref={descRef} type="text" className="form-control me-2" placeholder="Descripcion" value={desc} onChange={handleDescChange} />
            </div>
            <div className="col-md-2">
            <input type="checkbox" checked={importante} onChange={(e) => setImportante(e.target.checked)} className="form-check-input" id="importanteCheckbox"  />
            <label className="form-check-label" htmlFor="importanteCheckbox"> Importante </label>
            </div>
            <div className="col-md-2">
            <button type="submit" className="btn btn-dark">Agregar nota </button>
            </div>
          </div>
        </form>
        {error && (
          <div className="alert alert-danger mt-4"> Debe ingresar un titulo y descripción </div>
        )}
        <div className="container d-flex flex-wrap" style={{ marginTop: "20px", display: "flex", flexWrap: "wrap" }}>
          {notas.map((n) => (
            <div id="nota" key={n.id} className="Notas" style={{
              backgroundColor: n.importante ? "#ff3737" : "#EFDB51",
              padding: "10px",
              borderRadius: "10px",
              marginRight: "50px",
              marginBottom: "20px",
              boxShadow: "5px 5px 15px rgba(10, 5, 5, 0.1)" }}>
              <h2 id="letra">{n.titulo}</h2>
              <p id="letra">{n.desc}</p>
            </div>
          ))}
        </div>
      </div>
  );
}

export default PagNotas;
