import React from "react";
import ReactDOM  from "react-dom/client";
import ItemNotas from "./ItemNotas";
import PagNotas from "./PagNotas";
import './Estilo.css'

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <div className='container'>
    <PagNotas></PagNotas>
    <ItemNotas></ItemNotas>
  </div>
);